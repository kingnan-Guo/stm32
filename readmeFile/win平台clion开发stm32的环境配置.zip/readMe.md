文档 https://zhuanlan.zhihu.com/p/145801160


下载
stm32cubemx  https://www.st.com/en/development-tools/stm32cubemx.html
OpenOCD https://gnutoolchains.com/arm-eabi/openocd/
MinGW   https://osdn.net/projects/mingw/releases/
arm-none-eabi-gcc   https://developer.arm.com/downloads/-/gnu-rm


win 平台下 设置环境变量

D:\ProgramData\stm32\arm-gnu-toolchain\arm-gnu-toolchain-13.3.rel1-mingw-w64-i686-arm-none-eabi\arm-none-eabi\bin

D:\ProgramData\stm32\arm-gnu-toolchain\arm-gnu-toolchain-13.3.rel1-mingw-w64-i686-arm-none-eabi\bin
D:\ProgramData\stm32\openocd\OpenOCD-20240916-0.12.0\bin

理论上来说 还有 mingw64 


cubeMx配置步骤







macos 平台下
也是 下载文件后 配置环境变量
export PATH="/Users/zhengyuxiang/Documents/program/stm32/arm-gnu-toolchain-13.3.rel1-x86_64-apple-darwin/bin:$PATH"





